package com.libra.qrscanner

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.util.Log
import android.util.Size
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.FirebaseFirestore
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class MainActivity : AppCompatActivity() {
    
    private lateinit var previewView: PreviewView
    private lateinit var bookIdText: TextView
    private lateinit var titleText: TextView
    private lateinit var studentUidInput: EditText
    private lateinit var cameraExecutor: ExecutorService
    private var imageAnalyzer: ImageAnalysis? = null
    private var toneGen: ToneGenerator? = null
    
    private val CAMERA_PERMISSION_CODE = 100
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
        
        setContentView(R.layout.activity_main)
        
        previewView = findViewById(R.id.previewView)
        bookIdText = findViewById(R.id.bookIdText)
        titleText = findViewById(R.id.titleText)
        studentUidInput = findViewById(R.id.studentUidInput)
        
        cameraExecutor = Executors.newSingleThreadExecutor()
        
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, CAMERA_PERMISSION_CODE)
        }
    }
    
    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            
            imageAnalyzer = ImageAnalysis.Builder()
                .setTargetResolution(Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, QrAnalyzer { qrResult ->
                        runOnUiThread {
                            handleScanResult(qrResult)
                        }
                    })
                }
            
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalyzer)
            } catch (e: Exception) {
                Log.e(TAG, "Camera binding failed", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }
    
    private fun handleScanResult(result: QrScanResult) {
        if (result.success) {
            bookIdText.text = "Book ID: ${result.bookId}"
            titleText.text = "Title: ${result.title}"
            bookIdText.visibility = View.VISIBLE
            titleText.visibility = View.VISIBLE
            previewView.visibility = View.GONE
            
            // Play sound & vibrate
            toneGen?.startTone(ToneGenerator.TONE_DTMF_0, 150)
            // Vibrate would go here with vibrator service
            
            Toast.makeText(this, "Book scanned! Enter Student UID", Toast.LENGTH_SHORT).show()
        }
    }
    
    fun onIssueClicked(view: View) {
        val uid = studentUidInput.text.toString().trim()
        if (uid.isEmpty()) {
            Toast.makeText(this, "Enter Student UID", Toast.LENGTH_SHORT).show()
            return
        }
        
        sendToFirebase("issue", bookIdText.text.toString().replace("Book ID: ", ""), uid, titleText.text.toString().replace("Title: ", ""))
        resetScanner()
    }
    
    fun onReturnClicked(view: View) {
        val uid = studentUidInput.text.toString().trim()
        if (uid.isEmpty()) {
            Toast.makeText(this, "Enter Student UID", Toast.LENGTH_SHORT).show()
            return
        }
        
        sendToFirebase("return", bookIdText.text.toString().replace("Book ID: ", ""), uid, titleText.text.toString().replace("Title: ", ""))
        resetScanner()
    }
    
    private fun sendToFirebase(action: String, bookId: String, uid: String, title: String) {
        val db = FirebaseFirestore.getInstance()
        val data = hashMapOf(
            "action" to action,
            "bookId" to bookId,
            "title" to title,
            "studentUid" to uid,
            "timestamp" to SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        )
        
        db.collection(action + "s")
            .add(data)
            .addOnSuccessListener {
                Toast.makeText(this, "${action.capitalize()} recorded!", Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }
    
    private fun resetScanner() {
        bookIdText.visibility = View.GONE
        titleText.visibility = View.GONE
        previewView.visibility = View.VISIBLE
        studentUidInput.text.clear()
    }
    
    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        toneGen?.release()
    }
    
    companion object {
        private const val TAG = "LibraQRScanner"
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
    }
}

class QrAnalyzer(private val onQrFound: (QrScanResult) -> Unit) : ImageAnalysis.Analyzer {
    
    private val scanner = BarcodeScanning.getClient()
    
    @androidx.camera.core.ExperimentalGetImage
    override fun analyze(imageProxy: androidx.camera.core.ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            
            scanner.process(image)
                .addOnSuccessListener { barcodes ->
                    for (barcode in barcodes) {
                        if (barcode.format == Barcode.FORMAT_QR_CODE) {
                            val rawValue = barcode.rawValue ?: continue
                            val result = parseLibraQR(rawValue)
                            if (result.success) {
                                onQrFound(result)
                                imageProxy.close() // Close after processing
                                return
                            }
                        }
                    }
                }
                .addOnFailureListener { }
                .addOnCompleteListener { imageProxy.close() }
        } else {
            imageProxy.close()
        }
    }
}

data class QrScanResult(
    val success: Boolean,
    val bookId: String = "",
    val title: String = ""
)

fun parseLibraQR(raw: String): QrScanResult {
    if (!raw.startsWith("LIBRACORE:")) return QrScanResult(false)
    val parts = raw.substring(10).split(":", limit = 2)
    if (parts.size == 2) {
        return QrScanResult(true, parts[0], parts[1])
    }
    return QrScanResult(false)
}
