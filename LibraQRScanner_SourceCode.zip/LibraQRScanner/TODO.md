# LibraQRScanner Development TODO

## Plan Breakdown
1. [x] Create project root structure and key Gradle files
2. [x] Create AndroidManifest.xml and permissions
3. [x] Create MainActivity.kt with scanner logic
4. [x] Create layouts (activity_main.xml)
5. [x] Add Firebase config and data send logic
6. [ ] Test scanner in emulator/device
7. [ ] Build signed APK
8. [ ] [Complete] Install and demo APK

Progress tracked here after each step.
