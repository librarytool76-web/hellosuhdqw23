@echo off
setlocal

set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
@rem if "%OS%" == "Windows_NT" set DIRNAME=%~dp0%

@rem Find gradle-wrapper.jar if it exists
if exist "%DIRNAME%\gradle\wrapper\gradle-wrapper.jar" goto checkJava

@rem Find gradle-wrapper.jar in expected location
if exist "%DIRNAME%\..\gradle\wrapper\gradle-wrapper.jar" goto checkJava

@rem Provide helpful message if gradle-wrapper.jar not found
echo Gradle wrapper not found.
echo Run `gradlew` in a directory containing a gradle wrapper, or
echo install Gradle directly.
goto fail

:checkJava
@rem Find a JVM
if defined JAVA_HOME goto findJavaFromJavaHome

set JAVA_EXE=java.exe
%JAVA_EXE% -version >NUL 2>&1
if "%ERRORLEVEL%" == "0" goto execute

echo.
echo ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH.
echo.
echo Please set the JAVA_HOME variable in your environment to match the
echo location of your Java installation.

goto fail

:findJavaFromJavaHome
set JAVA_HOME=%JAVA_HOME:"=%
set JAVA_EXE=%JAVA_HOME%/bin/java.exe

if exist "%JAVA_EXE%" goto execute

echo.
echo ERROR: JAVA_HOME is set to an invalid directory: %JAVA_HOME%
echo.
echo Please set the JAVA_HOME variable in your environment to match the
echo location of your Java installation.

goto fail

:execute
@rem Set the JVM options (if any)
set GRADLE_OPTS=

@rem Execute Gradle
"%JAVA_EXE%" %DEFAULT_JVM_OPTS% %JAVA_OPTS% %GRADLE_OPTS% "-Dorg.gradle.appname=%~n0" -classpath "%DIRNAME%\gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*

:end
@rem End local scope for the variables set by this batch file
if "%ERRORLEVEL%" == "0" goto mainEnd

:fail
rem Set variable GRADLE_EXIT_CONSOLE if you need the _script_ return code instead of
rem the _gradle_ return code.
if not "" == "%GRADLE_EXIT_CONSOLE%" exit /b 1
exit /b %ERRORLEVEL%

:mainEnd
if "%OS%"=="Windows_NT" endlocal

:omega
