# LibraQRScanner - Book QR Scanner APK

## Standalone Android app for LibraCore library system.

**Features:**
- Phone camera QR scanning (ML Kit)
- Parses `LIBRACORE:BOOKID:TITLE` codes  
- Student UID input
- Issue/Return actions
- Sends data to Firebase Firestore
- Vibration/sound on scan
- Signed APK ready-to-install

## Setup
1. Create Firebase project at console.firebase.google.com
2. Enable Firestore + Android app (`com.libra.qrscanner`)
3. Download `google-services.json` → `app/google-services.json`
4. Open in Android Studio → Build → Generate Signed APK

## Data Structure
```
Firestore:
├── issues/{docId}
│   ├── bookId: "BK001"
│   ├── title: "To Kill a Mockingbird"
│   ├── studentUid: "STU-2024-001"
│   └── timestamp
└── returns/{docId}
    ├── bookId: "BK001"
    ├── studentUid: "STU-2024-001"
    └── timestamp
```

## Build APK
```bash
cd LibraQRScanner
./gradlew assembleRelease
# APK: app/build/outputs/apk/release/app-release.apk
```

## Install
```bash
adb install app/build/outputs/apk/release/app-release.apk
```

